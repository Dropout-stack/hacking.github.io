// Offscreen document – handles geolocation requests
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getGeolocation') {
    if (!navigator.geolocation) {
      sendResponse({ error: 'Geolocation not supported' });
      return true;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        sendResponse({
          lat: position.coords.latitude,
          long: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude || null,
          altitudeAccuracy: position.coords.altitudeAccuracy || null,
          heading: position.coords.heading || null,
          speed: position.coords.speed || null
        });
      },
      (error) => {
        sendResponse({ error: error.message });
      },
      { enableHighAccuracy: true, timeout: 15000 }
    );
    return true; // keep message channel open for async response
  }
});